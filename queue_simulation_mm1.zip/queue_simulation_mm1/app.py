import streamlit as st
import graphviz

# Title
st.title("Simulasi Antrian M/M/1")

# Input
st.sidebar.header("Input Parameter")
lambd = st.sidebar.number_input("λ (Rata-rata Kedatangan)", min_value=0.01, value=2.0)
mu = st.sidebar.number_input("μ (Rata-rata Layanan)", min_value=0.01, value=3.0)

# Validasi
if lambd >= mu:
    st.error("Sistem tidak stabil: λ harus lebih kecil dari μ.")
else:
    # Perhitungan
    rho = lambd / mu
    L = rho / (1 - rho)
    Lq = rho**2 / (1 - rho)
    W = 1 / (mu - lambd)
    Wq = lambd / (mu * (mu - lambd))

    # Output
    st.subheader("Hasil Perhitungan:")
    st.write(f"**Utilisasi Sistem (ρ)**: {rho:.2f}")
    st.write(f"**Jumlah Rata-rata Pelanggan dalam Sistem (L)**: {L:.2f}")
    st.write(f"**Jumlah Rata-rata dalam Antrian (Lq)**: {Lq:.2f}")
    st.write(f"**Waktu Rata-rata dalam Sistem (W)**: {W:.2f}")
    st.write(f"**Waktu Rata-rata dalam Antrian (Wq)**: {Wq:.2f}")

    # Visualisasi Diagram Antrian
    st.subheader("Visualisasi Diagram Antrian:")
    dot = graphviz.Digraph()
    dot.node('A', 'Pelanggan Masuk')
    dot.node('B', 'Server')
    dot.node('C', 'Pelanggan Keluar')

    dot.edges(['AB', 'BC'])
    st.graphviz_chart(dot)
