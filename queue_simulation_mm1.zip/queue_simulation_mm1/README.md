# Simulasi Antrian M/M/1

Aplikasi ini menghitung performa sistem antrian berdasarkan teori M/M/1 Queue.

## Fitur
- Input parameter: λ dan μ
- Output perhitungan: ρ, L, Lq, W, Wq
- Visualisasi diagram alur antrian

## Cara Menjalankan
```bash
pip install -r requirements.txt
streamlit run app.py
```
